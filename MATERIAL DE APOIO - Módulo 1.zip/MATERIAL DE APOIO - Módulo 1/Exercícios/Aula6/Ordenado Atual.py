ordenadoAtual = float(input("Ordenado atual do Funcionario: "))

if ordenadoAtual < 500:
    reajuste = 15
elif ordenadoAtual <= 100:
    reajuste = 10
else:
    reajuste = 5

ordenadoReajuste = (ordenadoAtual * reajuste) / 100
ordenadoReajustado = ordenadoAtual + ordenadoReajuste

print(f"\nO reajuste sera de {reajuste}%, tera um acrescimo de {ordenadoReajuste}€ passara para {ordenadoReajustado}€.")
