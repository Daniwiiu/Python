consumo = int(input("Qual a quantidade de energia consumida (em kwh)? "))
instalacao = input("Qual o tipo de instalacao eletrica? \nR para Residencias \nI para Industrias ")
