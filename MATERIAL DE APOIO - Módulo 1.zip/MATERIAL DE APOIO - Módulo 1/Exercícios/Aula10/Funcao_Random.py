import random

soma = 0
somaPares = 0
numerosSorteados = []

def SortearNumerosDezVezes():
    for x in range(1, 11):
        numero = random.randint(1, 100)
        numerosSorteados.append(numero)

    print(f"Os 10 valores sorteados foram: {numerosSorteados}")

def SomaParesDaLista():
    global somaPares
    for numero in numerosSorteados:
        if numero % 2 == 0:
            somaPares = somaPares + numero
    
    print(f"A soma dos valores pares contidos na lista {numerosSorteados} é {somaPares}")
    
def SomaNumerosLista():
    global soma
    for numero in numerosSorteados:
        soma = soma + numero
    print(f"A soma dos valores contidos na lista {numerosSorteados} é {soma}")

SortearNumerosDezVezes()
SomaNumerosLista()
SomaParesDaLista()