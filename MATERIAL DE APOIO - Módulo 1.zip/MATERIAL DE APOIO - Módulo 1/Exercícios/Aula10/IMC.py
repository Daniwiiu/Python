def calculo(peso,altura):
    return peso/(altura**2)

def faixas(resultado):
    if resultado < 18.5:
        print('Estas abaixo do peso')
    elif resultado < 24.9:
        print('Estas com Peso normal')
    elif resultado < 29.9:
        print('Estas acima do peso')
    elif resultado < 39.9:
        print('Estas com Obesidade Grau 1')
    else:
        print('Estas com Obesidade Grau II')

peso = int(input('Entre com o peso: '))
altura = float(input('Entre com a altura: '))
resultado = round(calculo(peso,altura),2)
faixas(resultado)