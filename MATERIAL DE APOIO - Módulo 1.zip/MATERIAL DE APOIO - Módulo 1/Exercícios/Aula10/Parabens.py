variavel = "Santiago de SharkCoders"

print(variavel.lower())
print(variavel.upper())
print(variavel.title())
