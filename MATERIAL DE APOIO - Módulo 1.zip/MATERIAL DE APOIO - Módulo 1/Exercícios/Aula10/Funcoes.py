def acharletra():
    nome = input('Digite a palavra? ')
    letra = input('Qual a letra? ')
    if letra in nome:
        print(f'Esta palavra tem a letra {letra}')
    else:
        print(f'Esta palavra não tem a letra {letra}')

def contaletra():
    soma = 0
    nome = input('Qual a frase? ')
    letra = input('Qual letras deseja procurar? ')
    for x in nome:
        if x == letra:
            soma += 1
    print(f'Esta frase tem {soma} letras {letra}')

def totalstr():
    frase = input('Digite uma frase? ')
    print(f'Esta frase tem {len(frase)} caracteres')