import random

numeroSorteados = []
numerosPares = []
somaPares = 0
soma = 0

def GeradorDeNumerosAleatorios():
    
    for i in range(1, 11):
        numero = random.randint(1, 2)
        numeroSorteados.append(numero)

    print()
    print(f"Os 10 valores sorteados foram: {numeroSorteados}")
    print()

def SomaDosNumerosPares():
    
    global somaPares
        
    for numero in numeroSorteados:
        if numero % 2 == 0:
            numerosPares.append(numero)
            somaPares += numero
    print(f"Os numeros pares sao: {numerosPares}")
    print()
    print(f"A soma dos valores pares contidos na lista {numeroSorteados} é {somaPares}")
    print()

def SomaTodosNumeros():
    
    global soma
    
    for numero in numeroSorteados:
        soma += numero
        
    soma += somaPares
    
    print(f"A soma dos valores pares contidos nas listas é {soma}")
    print()

GeradorDeNumerosAleatorios()
SomaDosNumerosPares()
SomaTodosNumeros()
