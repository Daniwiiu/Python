import random # Importa o módulo para gerar números aleatórios

# Variáveis globais para armazenar os resultados e as listas.
soma = 0
somaPares = 0
numerosSorteados = []
numerosPares = []


def NumerosRandom():
    """Gera 10 números aleatórios e imprime-os sem quebra de linha."""
    print("\n--- 1. CÁLCULO DA SOMA TOTAL ---")
    print()
    # O loop corre 10 vezes (de 1 a 10)
    for x in range(1, 11):
        numero = random.randint(1, 100) # Gera um número entre 1 e 100
        numerosSorteados.append(numero)
        
        # Lógica complexa para formatar a lista com colchetes e vírgulas.
        if x == 1:
            print(end="[ ")
            print(numero, end=" , ")
        elif x == 10:
            print(numero, end=" ]")
        else:
            print(numero, end=" , ")
    
    # Chama as próximas funções para processar a lista
    OrdenarNumeros(numerosSorteados)
    SomaNumeros(numerosSorteados)


def OrdenarNumeros(lista):
    """Ordena a lista passada e imprime."""
    lista.sort() # Ordena a lista
    print()
    print("\n--- Números Ordenados ---")
    print(f"\n{lista}")


def SomaNumeros(lista):
    """Calcula a soma de todos os elementos da lista e imprime o cálculo."""
    global soma # Indica que a variável global 'soma' será modificada
    print("\n--- Cálculo da Soma ---")
    print()
    tamanhoLista = len(lista)
    
    # Loop para somar e imprimir com sinais de '+' e '='
    for x in lista:
        # Nota: Esta lógica falha se houver números repetidos na lista.
        if x == tamanhoLista - 1:
            print(x, end=" = ")
        else:
            print(x, end=" + ")
        soma += x
    
    print(soma)
    input("\nEnter para Terminar\n") # Pausa o programa
    
    
def NumerosPares():
    """Identifica os números pares e inicia o cálculo da soma dos pares."""
    global somaPares     
    print("\n--- 2. ANÁLISE DE NÚMEROS PARES ---")
    print()
    
    # Itera sobre os números sorteados
    for x in numerosSorteados:
        if x % 2 == 0: # Verifica se é par (resto da divisão por 2 é 0)
            numerosPares.append(x)
            print(x, end=" , ")
          
    print()
    # Reutiliza a função SomaNumeros para somar apenas os pares.
    # Nota: Isto fará com que a variável global 'soma' seja alterada novamente
    # e o programa irá pausar prematuramente, mas foi mantido conforme solicitado.
    SomaNumeros(numerosPares)
            
            
def Main(): 
    """Função principal que inicia a execução das outras funções."""
    NumerosRandom()
    NumerosPares()
    
# Inicia a execução do programa
Main()