import random

# Definir as opções
opcoes = ["pedra", "papel", "tesoura"]

# Função para determinar o vencedor
def determinar_vencedor(jogador, computador):
    if jogador == computador:
        return "Empate"
    elif (jogador == "pedra" and computador == "tesoura") or \
         (jogador == "papel" and computador == "pedra") or \
         (jogador == "tesoura" and computador == "papel"):
        return "Você venceu!"
    else:
        return "Computador venceu!"

# Iniciar o jogo
while True:
    # Solicitar a escolha do jogador
    jogadorEscolha = input("Escolha pedra, papel ou tesoura (ou 'sair' para terminar): ").lower()
   
    if jogadorEscolha == "sair":
        print("Obrigado por jogar!")
        break
    elif jogadorEscolha not in opcoes:
        print("Escolha inválida, tente novamente.")
        continue
   
    # Escolha do computador
    computadorEscolha = random.choice(opcoes)
    print(f"Computador escolheu: {computadorEscolha}")

    # Determinar e imprimir o vencedor
    resultado = determinar_vencedor(jogadorEscolha, computadorEscolha)
    print(resultado)
