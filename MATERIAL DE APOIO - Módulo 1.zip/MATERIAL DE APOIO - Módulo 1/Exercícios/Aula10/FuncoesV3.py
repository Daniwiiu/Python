import random

def GerarMostrarLista():
    
    numeros_sorteados = []
    
    for x in range(1, 11): 
        numero = random.randint(1, 100)
        numeros_sorteados.append(numero)
        
    # Imprime a primeira parte do output
    print("Os 10 valores sorteados foram:", end=" ")
    
    # Usa um loop para imprimir os números separados por espaço (sem vírgula)
    for num in numeros_sorteados:
        # Primeiro elemento: abre o colchete e imprime o número
        if num == numeros_sorteados[0]:
            print(end="[ ")
        # Último elemento (assumindo que a lista tem 10): imprime o número e fecha o colchete
        elif num == numeros_sorteados[9]: 
            print(end=" ]")
        # Elementos do meio: imprime o número e um espaço
        else:
            print(num, end=" , ") 
        
    print()    
    return numeros_sorteados


def SomaParesMostrar(lista):
    
    pares_encontrados = []
    soma_pares = 0
    for num in lista:
        if num % 2 == 0:
            soma_pares += num
            pares_encontrados.append(num)
            
    print("\nA segunda função irá informar qual a Soma de todos os números Pares, contidos na Lista.")
    
    # --- Lógica de Formatação (Lista de Pares) ---
    print("\nNúmeros Pares Encontrados:", end=" ")
    
    # 1. Imprime o primeiro elemento, abrindo o colchete.
    print("[", pares_encontrados[0], end=" ")
        
    # 2. Itera sobre o resto da lista (a partir do segundo elemento)
    for num in pares_encontrados[1:]:
        print(num, end=" ")
        
    # 3. Fecha o colchete após o loop
    print("]")

    print() # Nova linha
    
    # 3. Imprime o resultado final
    print(f"A soma dos valores pares é: {soma_pares}")


def Main():
    # Passo 1: Gerar e mostrar a lista
    lista_de_numeros = GerarMostrarLista()
    
    # Passo 2: Analisar e mostrar a soma dos pares
    SomaParesMostrar(lista_de_numeros)

# Inicia o programa
Main()