def QuantasVezesTemLetraTemNaFrase():
    quantidadeLetra = 0
    frase = input("Qual a frase: ")
    letra = input("Qual a letra: ")
    
    # Para cada elemento dentro da frase:
    for elemento in frase:
        # Se o elemento for igual a letra:
        if elemento == letra:
            # Acrescentar + 1 a quantidadeLetra
            quantidadeLetra = quantidadeLetra + 1
            
    print(f"A letra {letra} existe {quantidadeLetra} vezes dentro da frase: {frase}")

QuantasVezesTemLetraTemNaFrase()
    

