def AcharLetraNaFrase():
  frase = input("Qual a frase: ")
  letra = input("Qual a letra: ")
  
  if letra in frase:
    print(f"A letra {letra} existe dentro da frase: {frase}")
  else: 
    print(f"A letra {letra} nao existe dentro da frase: {frase}")

AcharLetraNaFrase()
