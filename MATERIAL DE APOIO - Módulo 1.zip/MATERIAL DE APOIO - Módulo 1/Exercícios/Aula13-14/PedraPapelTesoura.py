from random import randint
import os

def limpar():
    os.system('cls')

def Cabecalho(texto):
    limpar()
    cumprimento = len(texto) + 6
    print()
    print("="*cumprimento)
    print(f"|| {texto} ||")
    print("="*cumprimento)
    print()
    
def SubCabecalho(texto):
    print()
    print(f"### {texto} ###")
    print()

def Menu(): 
    Cabecalho("Jogo do Pedra Papel Tesoura")
    SubCabecalho("Menu")
    escolha = int(input(" 1 - Jogar contra PC \n 2 - Jogar contra Jogador \n 0 - Sair\n\n Escolha: "))
    
    return escolha
    
def Jogar():
    print("\n 1 - Pedra \n 2 - Papel \n 3 - Tesoura \n 0 - Sair\n")
    
def JogoPC():
    SubCabecalho("Jogo Jogador 1 contra PC")
    Jogar()
    jogadaUm = int(input("Jodador 1: ")) - 1
    jogadaDois = randint(0,2)
    LogicaJogo(jogadaUm, jogadaDois)
    
def JogoPlayer():
    SubCabecalho("Jogo Jogador 1 contra Jogador 2")
    Jogar()
    jogadaUm = int(input("Jodador 1: ")) - 1
    jogadaDois = int(input("\nJodador 2: ")) - 1
    LogicaJogo(jogadaUm,jogadaDois)
    
def LogicaJogo(jogadaUm, jogadaDois):
    items = ['Pedra', 'Papel', 'Tesoura']
    print(f"O Jogador 1 escolheu {items[jogadaUm]} e o jogador 2 escolheu {items[jogadaDois]}")
    if jogadaUm == 0:
        if jogadaDois == 0:            
            print("\n # Empate #")
        if jogadaDois == 1:
            print("\n # Jogador 2 Ganhou! #")
        if jogadaDois == 2:
            print("\n # Jogador 1 Ganhou! #")
    if jogadaUm == 1:
        if jogadaDois == 0: 
            print("\n # Jogador 1 Ganhou! #")           
        if jogadaDois == 1:
            print("\n # Empate #")
        if jogadaDois == 2:
            print("\n # Jogador 2 Ganhou! #")
    if jogadaUm == 2:
        if jogadaDois == 0:            
            print("\n # Jogador 2 Ganhou! #")
        if jogadaDois == 1:
            print("\n # Jogador 1 Ganhou! #")
        if jogadaDois == 2:
            print("\n # Empate #")
            
    input("\n Enter Para Continuar")
    
    
def Jogo():
    Cabecalho("Jogo do Pedra Papel Tesoura")
    input("\n\nEnter Para Inicar")
    while True:
        limpar()
        escolha = Menu()
        limpar()
        if escolha == 0:
            limpar()
            print(" # Sayonara # ".upper)
            break
        elif escolha == 1:
            JogoPC()
        elif escolha == 2:
            JogoPlayer()
        else:
            SubCabecalho("Escolha nao valida!")
    
Jogo()