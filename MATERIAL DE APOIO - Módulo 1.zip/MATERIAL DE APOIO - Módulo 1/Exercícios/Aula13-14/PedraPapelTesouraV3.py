import os

def Limpar():
    os.system("cls")

def Cabecalho(texto):
    tamanho = len(texto) + 6
    Limpar()
    print()
    print("="*tamanho)
    print(f"|| {texto} ||")
    print("="*tamanho)
    print()

def SubCabecalho(texto):
    print()
    print(f"### {texto} ###")
    print()
    
def Menu():
    Cabecalho("Jogo do Pedra Papel Tesoura")
    SubCabecalho("Menu")
    escolha = int(input(" 1 - Jogar contra PC \n 2 - Jogar contra Jogador \n 0 - Sair\n\n Escolha: "))
    
    return escolha
    
def Jogo():
    Cabecalho("Jogo Pedra Papel Tesoura")
    input("\n Enter Para Continuar")
    while True:
        escolha = Menu()
        if escolha == 0:
            SubCabecalho("Sayonara".upper())
            break
        elif escolha == 1:
            JogoPC()
        elif escolha == 2:
            JogoPlayer()

Jogo()