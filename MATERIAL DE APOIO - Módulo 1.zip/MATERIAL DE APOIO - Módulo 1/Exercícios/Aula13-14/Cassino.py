from random import randint
from time import sleep

saldo = randint(100,200)

print('=-' * 14)
print('Bem Vindo ao Cassino Tugabet')
print('=-' * 14)

def menu():
    while True:
        if saldo > 0:
            print()
            print('Os jogos disponíveis são:\n1 - Slot Machine\n2 - Black Jack 21')
            opc = int(input('Escolha seu jogo: '))
            if opc == 1:
                print()
                slot()
            elif opc == 2:
                print()
                blackjack()
        else:
            print()
            print('Sem saldo suficiente! Volte em outro dia.')
            break

def slot():
    global saldo
    # Slot machine
    #  - São tres linhas de figuras (numeros ou palavras)
    #  - Os prémios são da seguinte maneira:
    #  - 3 iguais (* 100), 2 iguais (* 5), 3 diferente (perde)
    li = []

    for x in range(3):
        n = randint(1, 6)
        li.append(n)

    print('Bem vindo ao Slot\n')
    print('3 numeros iguais = Aposta x 50\n2 numeros iguais = Aposta x 3\n3 numeros diferentes = Perde o valor apostado\n')
    print(f'Seu saldo atual é de {saldo} euros')
    print()
    aposta = int(input('Digite o montate que deseja apostar: '))
    if saldo >= aposta:
        input('Aperte ENTER para iniciar')
        print('Girando ...')
        sleep(2)
        for x in li:
            print([x], end='  ')
            sleep(2)
        if li[0] == li[1] or li[0] == li[2] or li[1] == li[2]:
            ganhos = aposta * 3
            saldo += ganhos
            print()
            print(f'Parabens! Fez uma dupla e ganhou {ganhos} euros')
            print(f'Saldo atual é {saldo} euros')
        else:
            print()
            saldo -= aposta
            print(f'É uma pena! Perdeste a aposta')
            print(f'Saldo atual é {saldo} euros')

def blackjack():
    global saldo
    # Black Jack Simples (jogo do 21)
    #  - Apenas jogam com as cartas numéricas (2 a 10)
    #  - Inicia com uma carta aleatória entre 2 a 10
    #  - Pode comprar mais cartas ao longo do jogo, se passar de 21 perde
    #  - Quando quiser parar comparar o seu número com o da Banca (14 a 21)
    print('Bem vindo ao Black Jack\n')
    print('Inicias com uma carta do baralho\nPodes comprar quantas cartas quiser\nCaso ultrapasse 21 pontos você perde\nQuando quiseres pode parar de comprar\nA banca joga a carta dela. O maior ganha!\n')
    print(f'Seu saldo atual é de {saldo} euros\n')
    cartas = randint(2,10)
    aposta = int(input('Digite o montate que deseja apostar: '))
    if saldo >= aposta:
        print(f'\nIniciou com {cartas} pontos\n')
        while True:
            opc = int(input('Deseja comprar mais cartas?\n1 - SIM\n2 - Não\nOpção: '))
            if opc == 1:
                cartas += randint(2,10)
                print(f'\nEstas com {cartas} pontos\n')
                if cartas > 21:
                    saldo -= aposta
                    print(f'É uma pena! Passaste de 21 pontos.')
                    print(f'Saldo atual é {saldo} euros')
                    break
            elif opc == 2:
                banca = randint(15,21)
                print(f'\nA banca somou {banca} pontos.')
                if cartas > banca:
                    print()
                    ganhos = aposta * 2
                    saldo += ganhos
                    print(f'Parabens! Ganhaste a banca! Somou mais {ganhos} euros')
                    print(f'Seu saldo atual é de {saldo} euros\n')
                    break
                elif cartas < banca:
                    saldo -= aposta
                    print(f'É uma pena! Perdeste a aposta')
                    print(f'Saldo atual é {saldo} euros')
                    break
                else:
                    print(f'Foi um empate!')
                    print(f'Continuas com {saldo} euros')
                    break


menu()