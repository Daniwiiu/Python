nota = int(input('Nota de avaliacao: '))

match nota:
    case 20:
        avaliacao = "Excelente"
    case 18:
        avaliacao = "Muito Bom"
    case 16:
        avaliacao = "Bom"
    case _:
        avaliacao = "Nota Invalida"

print(f"A sua avalicao foi: {avaliacao}")
