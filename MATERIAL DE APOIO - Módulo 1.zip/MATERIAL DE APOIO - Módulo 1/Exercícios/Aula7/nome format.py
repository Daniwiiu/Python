nome = "Ana"
idade = 25
mensagem = f"O meu nome é {nome} e tenho {idade} anos."

print(mensagem)