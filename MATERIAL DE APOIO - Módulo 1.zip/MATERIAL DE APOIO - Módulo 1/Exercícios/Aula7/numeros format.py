preco = 49.99
quantidade = 3
total = preco * quantidade
mensagem = f"O preço por unidade é {preco:.2f}€. O total para {quantidade} unidades é {total:.2f}€."
# .2f - representa casas decimais

print(mensagem)