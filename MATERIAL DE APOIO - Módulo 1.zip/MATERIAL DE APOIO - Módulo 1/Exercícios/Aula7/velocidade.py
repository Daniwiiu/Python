# Solicitar a velocidade do condutor
velocidade = float(input("Por favor, insira a velocidade em km/h: "))

# Definir o limite de velocidade
limite_velocidade = 80
valor_por_km = 2

# Verificar se a velocidade está acima do limite permitido
if velocidade > limite_velocidade:
    excesso_velocidade = velocidade - limite_velocidade
    multa = excesso_velocidade * valor_por_km
    mensagem = f"Está acima do limite permitido. A multa foi gerada no valor de {multa:.2f} euros."
else:
    mensagem = "Está dentro do limite. Boa viagem!"

# Exibir a mensagem
print(mensagem)