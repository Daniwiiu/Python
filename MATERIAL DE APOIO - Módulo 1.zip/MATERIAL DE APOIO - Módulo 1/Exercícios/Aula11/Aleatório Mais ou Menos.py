from random import randint

def HighAndLow():
    
    numerosecreto = randint(1,100)
    contador = 0

    print('Escolha um número entre 1 e 100')
    print()

    while True:
        contador +=1
        escolha = int(input('Digite seu palpite: '))
        if numerosecreto > escolha:
            print('Errado! O número é maior')
        elif numerosecreto < escolha:
            print('Errado! O número é menor')
        else:
            print("Parabens! Voce Acertou!")
            break

    print('Foram necessárias',contador,'jogadas')

HighAndLow()