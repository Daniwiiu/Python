from random import randint

def DadosSeisESeis():

    contador = 0
    while True:
        contador += 1
        dadoUm = randint(1, 6)
        dadoDois = randint(1,6)
        print(f'Dado 1: {dadoUm} / Dado 2: {dadoDois}\n')
        if (dadoUm == 6) and (dadoDois == 6):
            print(f'Foram necessárias {contador} vezes para aparecer dois dados iguais a 6')
            break
        
DadosSeisESeis()
