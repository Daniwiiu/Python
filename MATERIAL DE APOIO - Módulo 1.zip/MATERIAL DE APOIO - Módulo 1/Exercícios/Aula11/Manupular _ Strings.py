import Funcoes

print('=-' * 12)
print('MANIPULAÇÃO DE STRING')
print('=-' * 12)

while True:
    print()
    print('0: Sair\n1: Achar Letras\n2: Conta Letras\n3: Conta Caracteres')
    esc = int(input('Escolha sua opção: '))
    if esc == 0:
        print()
        print('Obrigado por utilizar o programa')
        break
    elif esc == 1:
        print()
        Funcoes.acharletra()
    elif esc == 2:
        print()
        Funcoes.contaletra()
    elif esc == 3:
        print()
        Funcoes.totalstr()
    else:
        print('Função Inválida')