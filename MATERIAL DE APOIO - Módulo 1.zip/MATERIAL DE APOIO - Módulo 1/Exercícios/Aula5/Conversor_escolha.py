euro=float(input('Quantos euros você deseja converter? '))
print()
print('''Qual moeda deseja converter:
[0] Real Brasileiro
[1] Bath Tailandes''')
moeda=int(input('Escolha sua opção: '))
real=5.32*euro
baht=31.10*euro
print()
if moeda==0:
    print('Isso lhe dará', real, 'Reais Brasileiros')
else:
    print('Isso lhe dará', baht, 'em Bath Tailandes')