print('=-'*15)
print('Calculo de Combustível de F1')
print('=-'*15)

km=int(input('Quantos kilometros tem a pista? '))
voltas=int(input('Quantas voltas terá a competição? '))
print('Como estão as condições climáticas? \n 1 - Bom \n 2 - Chuvoso')
clima=int(input('Digite sua opção: '))

kmTotal = km*voltas
bomFerrari = round((kmTotal/3)*2.5,2)
chuvaFerrari = round((kmTotal/2.7)*2.5,2)
bomHonda = round((kmTotal/3.4)*2.5,2)
chuvaHonda = round((kmTotal/3)*2.5,2)

print()

if clima == 1:
    print('Teremos um total de',kmTotal,'kilomêtros nesta Prova. Com o clima favorável, serão gastos',bomFerrari,'euros de combustível para os carros da Ferrari e',bomHonda,'euros de combustível para os carros da Honda')
else:
    print('Teremos um total de',kmTotal,'kilomêtros nesta Prova. Com o clima chuvoso, serão gastos',chuvaFerrari,'euros de combustível para os carros da Ferrari e',chuvaHonda,'euros de combustível para os carros da Honda')