maior = 0
menor = 0
soma = 0

for contador in range(1,6):
    peso = float(input(f'\nEntre com o {contador}º peso: '))
    soma = soma + peso
    print(f"\nO peso introduzido foi: {peso:.2f}kg")
    input("\nCarrega Enter para continuar")
    
    
    # Se o contador for a primeira vez: Maior e Menor são igual ao Peso
    if contador == 1:
        maior = menor = peso
    # Se o Peso for maior que Maior, então Maior é igual ao Peso
    if peso > maior:
        maior = peso
    # Se o Peso for menor que Menor, então Menor é igual ao Peso
    if peso < menor:
        menor = peso
    
media = soma / 5
print()
print(f"O número maior é: {maior:.2f}")
print(f"O número menor é: {menor:.2f}")
print(f"A soma de todos os pesos é: {soma:.2f}")
print(f"A média dos pesos é: {media:.2f}")
input("\nEnter para Terminar\n")

