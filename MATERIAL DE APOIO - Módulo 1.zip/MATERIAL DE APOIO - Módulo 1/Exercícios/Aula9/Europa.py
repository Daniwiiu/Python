paises = ['França', 'Portugal', 'Espanha', 'Italia', 'Alemanha']

while True:
    
    escolha = input('\nEscolha um país da Europa: ')
    
    if escolha in paises:
        print('\nParabens!\n')
        break
    
    else:
        print('\nNão há este pais na lista')
        
