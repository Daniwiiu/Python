inicio = int(input("\nDigite o termo inicial: "))
final = int(input("\nDigite o número final: "))
soma = 0

print("\n\nOs valores somados sao: ")

for valor in range(inicio, final + 1):
    soma += valor
    if valor == inicio:
        print(f"[ {valor}", end=' + ')
    elif valor == final:
        print(valor, end=" ]" )
    else:
        print(valor, end=' + ')

print()
print(f'\nA soma de todos os números de {inicio} até {final} é {soma}\n')
