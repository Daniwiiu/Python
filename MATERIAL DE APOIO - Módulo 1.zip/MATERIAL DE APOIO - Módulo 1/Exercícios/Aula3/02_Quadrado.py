lado=float(input('Entre com um lado: '))
print()
print('A área do quadrado é', lado*lado, 'm2 e o perímetro é', lado*4, 'm')