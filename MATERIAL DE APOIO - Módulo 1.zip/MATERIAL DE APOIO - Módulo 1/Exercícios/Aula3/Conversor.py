euro=float(input('Quantos euros você deseja converter? '))
real=6.32
baht=38.10
print()
print('Isso lhe dará', euro*real, 'Reais Brasileiros e', euro*baht, 'em Bath Tailandes')