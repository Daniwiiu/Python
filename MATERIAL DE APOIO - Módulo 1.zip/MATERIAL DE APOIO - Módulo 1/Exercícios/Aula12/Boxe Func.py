from random import randint
from time import sleep

def Luta():
    lutadorUm = 100
    lutadorDois = 100
    
    while True:
        socoUm = randint(1,25)
        socoDois = randint(1,25)
        
        lutadorDois -= socoUm                
        if lutadorDois <= 0:
            lutadorDois = 0
            print("O Lutador 1 ganhou!")
            break
        
        print(f"O lutador 1 deu um soco de forca {socoUm}, e o Lutador 2 ficou com {lutadorDois} pontos de vida!")
        sleep(1)
        
        lutadorUm -= socoDois
        if lutadorUm <= 0:
            lutadorUm = 0
            print("O Lutador 2 ganhou!")
            break
        
        print(f"O lutador 2 deu um soco de forca {socoDois}, e o Lutador 1 ficou com {lutadorUm} pontos de vida!")
        sleep(1)
        
Luta()