from time import sleep

def Contagem(contador):
    print(contador)
    sleep(1)

def ContagemDecrescente():
    contador = int(input("Qual o numero incial da contagem decrescente? "))
    
    # while True:
    #     if contador == 0:
    #         print("Blast Off!!!")
    #         break
    #     else:
    #         Contagem(contador)
    #         contador -= 1
            
    for i in range(contador):
        Contagem(contador)
        contador -= 1
        if contador == 0:
            print("Blast Off!!!")
            break
        
        
ContagemDecrescente()