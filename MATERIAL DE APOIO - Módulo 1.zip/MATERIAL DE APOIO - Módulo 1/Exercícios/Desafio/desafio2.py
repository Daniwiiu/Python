# Solicitar a quantidade de kWh consumida
kwh_consumida = float(input("Digite a quantidade de kWh consumida: "))

# Solicitar o tipo de instalação
tipo_instalacao = input("Digite o tipo de instalação (R para residências, I para indústrias, C para comércios): ").upper()

# Inicializando a variável de preço
preco = 0.0

# Calculando o preço com base no tipo de instalação e consumo de kWh
if tipo_instalacao == "R":
    if kwh_consumida <= 500:
        preco = kwh_consumida * 0.40
    else:
        preco = kwh_consumida * 0.65
elif tipo_instalacao == "C":
    if kwh_consumida <= 1000:
        preco = kwh_consumida * 0.55
    else:
        preco = kwh_consumida * 0.60
elif tipo_instalacao == "I":
    if kwh_consumida <= 5000:
        preco = kwh_consumida * 0.55
    else:
        preco = kwh_consumida * 0.60
else:
    print("Tipo de instalação inválido. Por favor, digite R, I ou C.")

# Exibindo o preço a pagar, se o tipo de instalação for válido
if tipo_instalacao in ["R", "C", "I"]:
    print("O preço a pagar pelo fornecimento de energia elétrica é: {:.2f} euros".format(preco))
