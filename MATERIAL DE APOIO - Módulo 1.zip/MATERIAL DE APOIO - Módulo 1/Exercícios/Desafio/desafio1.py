# Solicitando ao usuário que insira o salário atual do funcionário
salario_atual = float(input("Digite o salário atual do funcionário em euros: "))

# Definindo a porcentagem de reajuste com base no salário atual
if salario_atual < 500:
    porcentagem_reajuste = 15
elif salario_atual <= 1000:
    porcentagem_reajuste = 10
else:
    porcentagem_reajuste = 5

# Calculando o valor do reajuste
valor_reajuste = salario_atual * (porcentagem_reajuste / 100)

# Calculando o novo salário
novo_salario = salario_atual + valor_reajuste

# Exibindo o valor do novo salário
print("O novo salário do funcionário, após um reajuste de", porcentagem_reajuste, "%, é: {:.2f} euros".format(novo_salario))
