inicial = int(input('Escolha o numero inicial: '))
final = int(input('Escolha o numero final: '))


print(f"\nOs numeros entre {inicial} e {final}, de forma decrescente sao:")

inicial -= 1

while inicial > final:
    print(inicial, end=' ')
    inicial -= 1

print()
input("Enter para Terminar")

