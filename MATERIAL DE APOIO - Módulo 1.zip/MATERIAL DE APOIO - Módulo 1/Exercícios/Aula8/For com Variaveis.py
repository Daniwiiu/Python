inicial = int(input('Escolha o numero inicial: '))
final = int(input('Escolha o numero final: '))
incremento = int(input("Escolha o valor de incremento: "))

print(f"\nOs numeros entre {inicial} e {final}, com um incremento de {incremento}, sao:")

for numero in range(inicial, final + 1, incremento):
    print()
    print(numero, end=" ")

print()
input("Enter para Terminar")
