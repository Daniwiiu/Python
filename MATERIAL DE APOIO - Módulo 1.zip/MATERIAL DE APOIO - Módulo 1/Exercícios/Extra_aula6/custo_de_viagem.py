#custo de viagem
# Programa para calcular o custo total de uma viagem

# Solicitar a distância da viagem em quilómetros
distancia = float(input("Insira a distância da viagem em quilómetros: "))

# Solicitar o preço por quilómetro para diferentes meios de transporte
print("\nEscolha o meio de transporte:")
print("1. Carro (0,50 euros por km)")
print("2. Comboio (0,30 euros por km)")
print("3. Avião (1,00 euros por km)")

meio_transporte = int(input("Digite o número correspondente ao meio de transporte: "))

# Definir o preço por quilómetro com base no meio de transporte escolhido
if meio_transporte == 1:
    preco_por_km = 0.50
elif meio_transporte == 2:
    preco_por_km = 0.30
elif meio_transporte == 3:
    preco_por_km = 1.00
else:
    preco_por_km = 0
    print("Opção inválida. O custo não será calculado corretamente.")

# Solicitar a quantidade de pessoas na viagem
quantidade_pessoas = int(input("\nInsira a quantidade de pessoas na viagem: "))

# Calcular o custo total da viagem
custo_total = distancia * preco_por_km * quantidade_pessoas

# Exibir o custo total da viagem
print("\nResumo da Viagem:")
print("Distância: " + str(distancia) + " km")
print("Preço por km: €" + str(preco_por_km))
print("Quantidade de pessoas: " + str(quantidade_pessoas))
print("Custo Total da Viagem: €" + str(custo_total))
